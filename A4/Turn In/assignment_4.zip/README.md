# Assignment 4 Instructions 

1. First, make sure that all the .m and data files are in the same folder.
```
   The list of files are:
   assignment_four.m
   Kmeans.m
   ReadImage.m
   SingleL.m
   CompleteL.m
   data-2.txt
```

2. Next, open `assignment_four.m` in matlab.

3. Click the run button at the top.

4. You will most likely be prompted to change the current folder. Press the `add to path` button. 

5. The code will then run and display the relevant graphs in new windows. The relevant calculations will be displayed in the bottom `comand window`. You will likely have to scroll up to see all of them.