# Assignment 5 Instructions 

1. First, make sure that all the .m and data files are in the same folder.
```
   The list of files are:
   Assignment_five.m
   ValueIter.m
   test-data-for-MDP-1.txt
```

2. Next, open `Assignment_five.m` in matlab.

3. Click the run button at the top.

4. You will most likely be prompted to change the current folder. Press the `add to path` button. 

5. The code will then run and display the relevant graphs in new windows. The relevant calculations will be displayed in the bottom `comand window`. You will likely have to scroll up to see all of them.
