%% Value Iteration Algorithm
function [U, iter] = ValueIte(R, gamma, states, actions, T)
%% Parameters:
    % R - Reward Vector
    % gamma - The Discount factor
    % states - the number of states
    % actions - the number of actions
    % T - the action matrix

%% code:

converge = 0; % logical statement for convergence
epsilon = 1e-10; % set epsilon
delta = epsilon*(1 - gamma)^2/(2*gamma^2); % calculate delta from discount factor and epsilon
iter = 0; % initialize iteration counter
U = R; % initial utility vector

while ~converge
    iter = iter + 1; % count iterations
    old_U = U; % store last utility vector
    
    % horizon decision
    M = zeros(states,actions); % initialize action/state utility matrix
    for a = 1:actions % iterate over actions
        M(:,a) = T(:,:,a)*old_U; % calculate action/state utility
    end
    
    % Bellman Equation
    U = R + gamma*max(M,[],2);
    
    % check convergence
    if abs(sum(U - old_U)) < delta
        converge = 1;
    end
    
end

end
