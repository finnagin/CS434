%% Assignment 5
% Finn Womack & Rong Yu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Instructions:
% 1) Make sure all the .m files and data are in the same folder
% 2) open assignment_five.m in matlab
% 3) Click the run button at the top.
% 4) You will most likely be prompted to change the current folder. 
%    Press the add to path button.
% 5) The code will then run and display the relevant graphs in new windows. 
%    The relevant calculations will be displayed in the bottom comand 
%    window. You will likely have to scroll up to see all of them.

%%

clc; clear all; 

%% Problem 1

%% Import data
data = dlmread('test-data-for-MDP-1.txt');
% data = [3 2 0;... % states, actions, 0 is irrelevant
%     0.2 0.8 0; 0 0.2 0.8; 1 0 0;... % action one
%     0.9 0.05 0.05; 0.05 0.9 0.05; 0.05 0.05 0.9;... % action two
%     -1 -1 0]; % reward for each state

%% Initialization
states = data(1,1); actions = data(1,2); % find # of states & actions

% obtain transition matries for all states
M = data(2:end-1, :); 

% Action model/matrix
T = zeros(states, states, actions); % initialize action matracies
for a = 1:actions
    T(:,:,a) = M((1+(a-1)*states):a*states,:); % import actions
end

% Get Reward Vector
R = data(end, :); 
R = R';

% iterative value function defined in ValueIte.m

%% Problem 2

%% \beta = 0.1
beta1 = 0.1; % set discount factor
[U1, iter1] = ValueIte(R, beta1, states, actions, T); % run value iteration function
fprintf(['With beta = ', num2str(beta1),'\n']) % print the beta value used
fprintf('the optimal utility is \n')
display(U1) % print optimal utility

% calculate optimal policy
P1 = zeros(states, actions); % initialize action/state policy matrix
for a = 1:actions
    P1(:,a) = T(:,:,a)*U1; % calculate matrix
end
[OPi_1 Pi_1] = max(P1,[],2); % find the optimal policy for \beta = 0.1
fprintf('the optimal policy is \n')
display(Pi_1) % print optimal policy

%% \beta = 0.9
beta2 = 0.9; % set discount factor
[U2, iter2] = ValueIte(R, beta2, states, actions, T); % run value iteration function
fprintf(['With beta = ', num2str(beta2),'\n']) % print the beta value used
fprintf('the optimal utility is \n')
display(U2) % print optimal utility

% calculate optimal policy
P2 = zeros(states, actions); % initialize action/state policy matrix
for a = 1:actions
    P2(:,a) = T(:,:,a)*U2; % calculate matrix
end
[OPi_2 Pi_2] = max(P2,[],2); % find the optimal policy for \beta = 0.9
fprintf('the optimal policy is \n')
display(Pi_2) % print optimal policy

